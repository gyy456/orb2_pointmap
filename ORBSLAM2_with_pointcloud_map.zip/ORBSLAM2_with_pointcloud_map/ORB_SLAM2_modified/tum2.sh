Examples/RGB-D/rgbd_tum ./Vocabulary/ORBvoc.txt ./Examples/RGB-D/TUM2.yaml ~/Documents/data/rgbd_dataset_freiburg2_pioneer_slam2/ ~/Documents/data/rgbd_dataset_freiburg2_pioneer_slam2/associate.txt
